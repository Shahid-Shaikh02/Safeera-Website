module.exports = {
  user: "SHAHID_SHAIKH",
  password: "sqlblastoise",
  connectString: "localhost/orclpdb" // or the address Oracle gave you
};
